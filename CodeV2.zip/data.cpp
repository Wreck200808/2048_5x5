#include<iostream>
#include "data.h"
using namespace std;
void data(){
    
}