#ifndef data_h
#define data_h
void data();
#endif