// play.h

#ifndef PLAY_H
#define PLAY_H

void play();

#endif