#include<iostream>
#include<fstream>
#include<cstdlib>
#include<vector>
#include<sstream>
#include<string>
#include<iterator>

using namespace std;
int data_variable[5][5];

//Check if the stored data is empty
bool checkifempty(){
    ifstream fin ("data.txt");
    if (fin.fail()) {
        cout << "Error in checkifempty! Game Exit" << endl;
        exit(1);
    }
    int t;
    if(fin >> t)
        return true;
    else
        return false;
    fin.close();
}
//Update the newest data to file
void addline(int boxes[5][5], int propsnum) {
    ofstream fout ("data.txt", ios::app);
    if (fout.fail()) {
        cout << "Error in addline! Game Exit" << endl;
        exit(1);
    }
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            fout << boxes[i][j] << " ";
        }
    }
    fout << propsnum << endl;
    fout.close();
}

//Extract the data of last unfinished game from data.txt
void readlastline(int boxes[5][5], int &popsnum){
    ifstream fin ("data.txt");
    if (fin.fail()) {
        cout << "Error in readlastline! Game Exit" << endl;
        exit(1);
    }
    string s, t, s1;
    while (getline(fin, s)){
        s1 = s;
    }
    stringstream linestream;
    linestream.str(s1);
    int num;
    for (int i = 0; i < 5; i++){
        for (int k = 0; k < 5; k++){
            linestream>>num;
            boxes[i][k]=num;
        }
    }
    linestream>>num;
    popsnum=num;
    fin.close();
}

//Choose the next position for new number randomly
void randselect(int data_variable[5][5], int x){
    int empty[25][2], empty_num=0, random;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if(data_variable[i][j]==0){
                empty[empty_num][0]=i;
                empty[empty_num][1]=j;
                empty_num+=1;
            }
        }
    }
    srand(time(NULL));
    random=rand() % empty_num;
    if(x==0){
        data_variable[empty[random][0]][empty[random][1]] = rand()%2+1;
    }
    else{
        data_variable[empty[random][0]][empty[random][1]] = 3;
    }
}

//delete data in data.txt
void deletedata(){
    ofstream fout("data.txt");
    if (fout.fail()) {
        cout << "Error in deletefile! Game Exit" << endl;
        exit(1);
    }
    fout.close();
}

//delete last line of data.txt
void deleteline(){
    string line;
    vector<string> lines;
    std::ifstream inputStream("data.txt");

    while (getline(inputStream,line)) {
        lines.push_back(line);
    }
    inputStream.close();

    std::fstream outputStream("data.txt", ios::out | ios::trunc);
    if (outputStream.is_open())
    {
        for (int i=0; i < lines.size()-1; i++)
        {
            outputStream << lines[i] << "\n";
        }
        outputStream.close();
    }


}