#ifndef PLAY_FUNCTION_H
#define PLAY_FUNCTION_H

void addline(int boxes[][5], int popsnum);
void readlastline(int boxes[][5], int &popsnum);
bool checkifempty();
void randselect(int data_variable[][5], int x);
void deletedata();
void deleteline();

#endif