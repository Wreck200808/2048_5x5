#include<iostream>
#include "display_start.h"
using namespace std;
void display_start(){
    cout << "Welcome to our 5X5 2048!" << endl;
    cout << "'p' stands for play and 'e' stands for exit." << endl;
    cout << "type in your choice and click 'enter' on your kerboard: ";
}