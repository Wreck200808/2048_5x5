#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;
int main(){
    ofstream fout ("data.txt", ios::app);
    if (fout.fail()) {
        cout << "Error in addline! Game Exit" << endl;
        exit(1);
    }
    fout.close();
    return 0;
}
