#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;
int data_variable[5][5];
void addline(int boxes[][5], int popsnum) {
    ofstream fout ("data.txt", ios::app);
    if (fout.fail()) {
        cout << "Error in addline! Game Exit" << endl;
        exit(1);
    }
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            fout << data_variable[i][j] << "";
        }
    }
    fout << popsnum << endl;
    fout.close();
}
void readlastline(int boxes[][5], int &popsnum){
    ifstream fin ("data.txt");
    if (fin.fail()) {
        cout << "Error in readlastline! Game Exit" << endl;
        exit(1);
    }
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
                fin >> data_variable[i][j];
            }
        }
    fin.close();
}

bool checkifempty(){
    ifstream fin ("data.txt");
    if (fin.fail()) {
        cout << "Error in checkifempty! Game Exit" << endl;
        exit(1);
    }
    int t;
    if(fin >> t)
        return true;
    else
        return false;
    fin.close();
}

void randselect(int data_variable[][5], int x){
    int empty[25][2], empty_num=0, random;
    for (int i = 0; i < 5; ++i) {
        for (int j = 0; j < 5; ++j) {
            if(data_variable[i][j]==0){
                empty[empty_num][0]=i;
                empty[empty_num][1]=j;
                empty_num+=1;
            }
        }
    }
    if(x==0){
        srand(time(NULL));
        random=rand() % empty_num;
        data_variable[empty[random][0]][empty[random][1]] = rand()%2+1;
    }
    else{
        data_variable[empty[random][0]][empty[random][1]] = 3;
    }
}


void deletefile(){
    ofstream fout("data.txt");
    if (fout.fail()) {
        cout << "Error in deletefile! Game Exit" << endl;
        exit(1);
    }
    fout.close();
}